package Student.Management.System;

import com.mysql.cj.xdevapi.Statement;

import java.sql.DriverManager;

public class Connection {
    Connection conn ;

    Statement statement ;

    Connection(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = (Connection) DriverManager.getConnection("jdbc:mysql:///student_management","root","12345678");
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
