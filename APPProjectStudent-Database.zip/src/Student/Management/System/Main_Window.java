package Student.Management.System;

import javax.swing.*;

public class Main_Window extends JFrame {

    Main_Window() {
        setSize(500, 500);
        setVisible(true);
    }
    public static void main(String[] args) {
        new Main_Window();
    }
}
